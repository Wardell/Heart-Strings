﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NAudio.Dmo
{
    /// <summary>
    /// Contains the name and CLSID of a DirectX Media Object
    /// </summary>
    public class DmoDescriptor
    {
        /// <summary>
        /// Name
        /// </summary>
        private string _Name;
		public string Name
		{
			get {return _Name;}
			private set {_Name = value;}
		}

        /// <summary>
        /// Clsid
        /// </summary>
        private Guid _Clsid;
		public Guid Clsid
		{
			get {return _Clsid;}
			private set {_Clsid = value;}
		}

        /// <summary>
        /// Initializes a new instance of DmoDescriptor
        /// </summary>
        public DmoDescriptor(string name, Guid clsid)
        {
            this.Name = name;
            this.Clsid = clsid;
        }
    }
}
