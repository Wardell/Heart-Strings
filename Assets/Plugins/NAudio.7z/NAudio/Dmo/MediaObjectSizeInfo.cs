﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NAudio.Dmo
{
    /// <summary>
    /// Media Object Size Info
    /// </summary>
    public class MediaObjectSizeInfo
    {
        /// <summary>
        /// Minimum Buffer Size, in bytes
        /// </summary>
        private int _Size;
		public int Size
		{
			get {return _Size;}
			private set {_Size = value;}
		}

        /// <summary>
        /// Max Lookahead
        /// </summary>
        private int _MaxLookahead;
		public int MaxLookahead
		{
			get {return _MaxLookahead;}
			private set {_MaxLookahead = value;}
		}

        /// <summary>
        /// Alignment
        /// </summary>
        private int _Alignment;
		public int Alignment
		{
			get {return _Alignment;}
			private set {_Alignment = value;}
		}

        /// <summary>
        /// Media Object Size Info
        /// </summary>
        public MediaObjectSizeInfo(int size, int maxLookahead, int alignment)
        {
            Size = size;
            MaxLookahead = maxLookahead;
            Alignment = alignment;
        }

        /// <summary>
        /// ToString
        /// </summary>        
        public override string ToString()
        {
            return String.Format("Size: {0}, Alignment {1}, MaxLookahead {2}",
                Size, Alignment, MaxLookahead);
        }

    }
}
