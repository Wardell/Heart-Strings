﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NAudio.Wave
{
    /// <summary>
    /// An interface for WaveStreams which can report notification of individual samples
    /// </summary>
    public interface ISampleNotifier
    {
        /// <summary>
        /// A sample has been detected
        /// </summary>
        event EventHandler<SampleEventArgs> Sample;
    }

    /// <summary>
    /// Sample event arguments
    /// </summary>
    public class SampleEventArgs : EventArgs
    {
        /// <summary>
        /// Left sample
        /// </summary>
       	private float _Left;
		public float Left
		{
			get {return _Left;}
			set {_Left = value;}
		}
        /// <summary>
        /// Right sample
        /// </summary>
        private float _Right;
		public float Right
		{
			get {return _Right;}
			set {_Right = value;}
		}

        /// <summary>
        /// Constructor
        /// </summary>
        public SampleEventArgs(float left, float right)
        {
            this.Left = left;
            this.Right = right;
        }
    }
}
